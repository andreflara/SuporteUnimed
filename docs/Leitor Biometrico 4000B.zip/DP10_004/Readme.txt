   -------------------------------------------------------------
			   DigitalPersona

                 DP10_004 Fingerprint Reader Driver and 
                       Recognition Engine Update                

                   	    Readme File 

		            April 2009
   -------------------------------------------------------------      

        (c) DigitalPersona, Inc., 2009. All rights reserved.



-------------------------
How to Use This Document
-------------------------
To view the Readme file on-screen in Windows Notepad, maximize the Notepad window. On the Format menu, click Word Wrap. To print the Readme file, open it in Notepad or another word processor, and then use the Print command on the File menu.


---------
CONTENTS
---------

1.   INSTALLATION

2.   COMPATIBILITY
     
3.   SYSTEM REQUIREMENTS

4.   RELEASE NOTES

5.   SUPPORT AND FEEDBACK


----------------
1. INSTALLATION
----------------

You must have local administrator rights to install this update on the supported operating systems. 

To start the installation, run Setup.msi on a machine that already has DigitalPersona product installed.


-----------------
2. COMPATIBILITY
-----------------

This update is compatible with the following DigitalPersona Hardware Products:

- U.are.U(R) 4500 Fingerprint Readers and Modules
- U.are.U(R) 4000B Fingerprint Readers and Modules
- U.are.U(R) Fingerprint Keyboard

This update is required to support HD and no-coating models of the products above with the following DigitalPersona Software Products:

- Gold SDK version 2.5 and 3.0
- Gold Fingerprint Recognition Software version 2.5 and 3.0
- Platinum SDK version 3.1 through 3.2
- Platinum Fingerprint Recognition Software version 3.1 through 3.2
- Pro WS and Server 3.2.0 through 3.5.1
- Pro Kiosk 1.0.0 through 1.0.3
- Online Client version 3.1 through 3.2

These software products were released in 2005 and 2006.

DigitalPersona Software Products released after 2006 do not require this update, and customers are encouraged to upgrade to these newer versions of software when possible.

If you are not certain whether your system needs this update, you can do the following:

  1. Open the \Windows\System32 folder.
  2. View the file versions installed for dpD00701.dll and dpHMatch.dll: right-click on each file, select Properties, click Details, and look at File Version.
  3. If dpD00701.dll is version 2.2.4.85 or dpHMatch.dll is version 2.4.0.82 to 3.0.0.149, this update is needed.


-----------------------
3. SYSTEM REQUIREMENTS
-----------------------

- Same as listed in the compatibility section.


-----------------
4. RELEASE NOTES
-----------------

4.1 This update addresses a compatibility issue with older versions of software supporting DigitalPersona U.are.U(R) HD and no-coating Fingerprint Readers and Modules. 

Applying this update modifies registry entries to add support for the above mentioned readers and modules and updates the Recognition Engine.

A reboot is required for the update to take effect.


4.2 Many of the software versions listed in the compatibility section above also require update DP00-001.

Customers should review DP00-001 (http://www.digitalpersona.com/index.php?id=bus_support_downloads_fp_download) and install this update as needed before installing DP10-004.


------------------------
5. SUPPORT AND FEEDBACK 
------------------------

If you have suggestions for future product releases or require technical support for your product, e-mail to techsupport@digitalpersona.com. In the subject line, type "U.are.U Fingerprint Reader support."

The DigitalPersona Web site, at http://www.digitalpersona.com, provides support for registered users as well.


